# This file is called a.py
def num_sides(name):
    if name == "triangle":
        return 3
