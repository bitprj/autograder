import builtins

pos = 0
def input(user_in=None):
    if user_in:
        print(user_in, end="")
    with open("input.txt", 'r') as f:
        global pos
        f.seek(pos)
        input_line = f.readline()[:-1] # cast to str if not from file
        pos = f.tell()
        print(input_line)
        return input_line

builtins.input = input

def num_sides(name):
    if name == "triangle":
        return 3
def test_input():
    name = input('name: ')
def test_loop():
    for i in range(1,5):
        print(i)
