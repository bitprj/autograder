def shape_name(num_sides):
    if num_sides == 3:
        return "triangle"
